#ifndef _ASPIC_H_
#define	_ASPIC_H_

#include <pic.inc>

#endif
